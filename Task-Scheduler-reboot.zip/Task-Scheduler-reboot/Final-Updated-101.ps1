﻿
$computer = Get-WMIObject Win32_ComputerSystem | Select-Object -ExpandProperty name

    $wmi = ""
    if (Test-Connection $computer -Quiet){
        $wmi = Get-WmiObject -Class win32_OperatingSystem -ComputerName $computer
        if (($wmi.ConvertToDateTime($wmi.LocalDateTime) – $wmi.ConvertToDateTime($wmi.LastBootUpTime)).minutes -gt 2){
            #Restart-Computer -ComputerName $computer -Force
            [void][System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void][System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") | out-null
[System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") | out-null
$TimeStart = Get-Date
$TimeEnd = $timeStart.addminutes(1)
Do
{
    $TimeNow = Get-Date
    if ($TimeNow -ge $TimeEnd)
    {
        Restart-Computer -ComputerName $computer -Force
    }
    else
    {
        $Balloon = new-object System.Windows.Forms.NotifyIcon
        $Balloon.Icon = [System.Drawing.SystemIcons]::Information
        $Balloon.BalloonTipText = "IT is requiring a reboot in order to maintain system stability supporting IT security measures. Please reboot at your earliest convenience."
        $Balloon.BalloonTipTitle = "Reboot Required"
        $Balloon.BalloonTipIcon = "Warning"
        $Balloon.Visible = $true;
        $Balloon.ShowBalloonTip(20000);
        $Balloon_MouseOver = [System.Windows.Forms.MouseEventHandler]{ $Balloon.ShowBalloonTip(20000) }
        $Balloon.add_MouseClick($Balloon_MouseOver)
        Unregister-Event -SourceIdentifier click_event -ErrorAction SilentlyContinue
        Register-ObjectEvent $Balloon BalloonTipClicked -sourceIdentifier click_event -Action {
            Add-Type -AssemblyName Microsoft.VisualBasic
            
            If ([Microsoft.VisualBasic.Interaction]::MsgBox('Would you like to reboot your machine now?', 'MsgBoxSetForeground,Question', 'System Maintenance') )
            { }
            else
            {
                shutdown -r -f
            }
            
        } | Out-Null
        
        Wait-Event -timeout 3 -sourceIdentifier click_event > $null
        Unregister-Event -SourceIdentifier click_event -ErrorAction SilentlyContinue
        $Balloon.Dispose()
    }

}
Until ($TimeNow -ge $TimeEnd)
        }
    }
