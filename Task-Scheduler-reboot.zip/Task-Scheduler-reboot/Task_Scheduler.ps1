﻿# Credentials to be configured in the scheduled task
$USER = "administrator"
$PASS ="G0767260n$"

# Scheduled task name
$TASKNAME = "Daily Script"

# Scheduled task folder
$TASKPATH = "Dattics"

# Scheduled task description
$DESCRIPTION = "Reboot checker"

# Script to schedule
# Mention the network path of startup_script.bat
$SCRIPT="\\Win-ree0h4k5v5u\c$\SCRIPTS\startup_script.bat"
########################################################

Function CreateScheduledTaskFolder ($TASKPATH)
{
    $ERRORACTIONPREFERENCE = "stop"
    $SCHEDULE_OBJECT = New-Object -ComObject schedule.service
    $SCHEDULE_OBJECT.connect()
    $ROOT = $SCHEDULE_OBJECT.GetFolder("\")
    Try {$null = $SCHEDULE_OBJECT.GetFolder($TASKPATH)}
    Catch { $null = $ROOT.CreateFolder($TASKPATH) }
    Finally { $ERRORACTIONPREFERENCE = "continue" } 
}


Function CreateScheduledTask ($TASKNAME, $TASKPATH)
{
    $ACTION = New-ScheduledTaskAction -Execute "$SCRIPT"
#Time-when script will execute    
$TRIGGER =  New-ScheduledTaskTrigger -Daily -At 4:06am
    Register-ScheduledTask -Action $ACTION -Trigger $TRIGGER -TaskName $TASKNAME -Description "$DESCRIPTION" -TaskPath $TASKPATH -RunLevel Highest
}

Function ConfigureScheduledTaskSettings ($TASKNAME, $TASKPATH)
{
    $SETTINGS = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -Hidden -ExecutionTimeLimit (New-TimeSpan -Minutes 30) -RestartCount 3
    Set-ScheduledTask -TaskName $TASKNAME -Settings $SETTINGS -TaskPath $TASKPATH 
}

CreateScheduledTaskFolder $TASKNAME $TASKPATH
CreateScheduledTask $TASKNAME $TASKPATH | Out-Null
ConfigureScheduledTaskSettings $TASKNAME $TASKPATH | Out-Null

$PASSWORD = ConvertTo-SecureString "$PASS" -AsPlainText -Force
$CREDENTIALS = New-Object -typename System.Management.Automation.PSCredential -argumentlist $USER, $PASSWORD

#Set-ScheduledTask -TaskName "$TASKNAME" -TaskPath "$TASKPATH" | Out-Null 
Set-ScheduledTask -TaskName "$TASKNAME" -TaskPath "$TASKPATH" -User "$USER" -Password "$PASS" | Out-Null
